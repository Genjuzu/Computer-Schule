#include "funktionen.h"



int main() {
    system("chcp 65001");
    system("cls");


// Übung1();
// Übung2();
Übung3();
// crypto();
//     system("pause");
//     system("cls");
// decrypt();
//arrayWhile();

    // system("pause");
    cout << endl << endl << endl << endl;
    return 0;
}
