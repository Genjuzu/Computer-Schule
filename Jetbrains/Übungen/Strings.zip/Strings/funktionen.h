#include <iostream>
#include <iomanip>
using namespace std;


#ifndef FUNKTIONEN_H
#define FUNKTIONEN_H


//Ausführbare Funktionen
void Übung1();
void Übung2();
void Übung3();
void Übung4();

void crypto();
void decrypt();


//Mathematische Funktionen
void reversstring();
void upstring();
void WhileCpy();
void ForCpy();
void namencryptographie();
void arrayWhile();

#endif //FUNKTIONEN_H
