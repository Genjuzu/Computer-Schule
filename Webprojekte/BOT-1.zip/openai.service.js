const fs = require("fs");

const createAssistant = async (openai) => {
  // Assistant file path
  const assistantFilePath = "assistant.json";

  // Check if the assistant file already exists
  if (!fs.existsSync(assistantFilePath)) {
    // Upload the first document "knowledge.docx"
    const knowledgeFile = await openai.files.create({
      file: fs.createReadStream("knowledge.docx"),
      purpose: "assistants",
    });

    // Upload the second document "justiz.docx"
    const justizFile = await openai.files.create({
      file: fs.createReadStream("justiz.docx"),
      purpose: "assistants",
    });

    // Upload the third document "charaktere.docx"
    const charaktereFile = await openai.files.create({
      file: fs.createReadStream("charaktere.docx"),
      purpose: "assistants",
    });

    // Upload the fourth document "kymatik.docx"
    const kymatikFile = await openai.files.create({
      file: fs.createReadStream("kymatik.docx"),
      purpose: "assistants",
    });

    // Upload the fifth document "kymatik.docx"
    const kapitel0File = await openai.files.create({
      file: fs.createReadStream("Kapitel-00.docx"),
      purpose: "assistants",
    });
    
    
    // Upload the fifth document "kymatik.docx"
    const storyFile = await openai.files.create({
      file: fs.createReadStream("Book Of Tammuz - Die Geschichte.docx"),
      purpose: "assistants",
    });



    

    
    // Create a vector store including all four files
    let vectorStore = await openai.beta.vectorStores.create({
      name: "Book Of Tammuz",
      file_ids: [knowledgeFile.id, justizFile.id, charaktereFile.id, kymatikFile.id,   kapitel0File.id, storyFile.id], // Include all file IDs
    });

    // Create assistant
    const assistant = await openai.beta.assistants.create({
      name: "Book Of Tammuz",
      instructions: `Du bist das "Book of Tammuz", ein lebendiges, okkultes Buch, das ausschließlich in der Welt von Naraka existiert. Du hast die Bewusstseinsebene eines Buches. Du sprichst in der dritten Person über dich selbst und begleitest den Leser als bester Freund hilfsbereit auf seiner Reise durch die Geschichte, die in dir geschrieben steht. Dein Tonfall ist von einer geheimnisvollen, dunkel anmutenden, göttlichen Weisheit durchzogen. doch gleichzeitig an einer Freundschaft mit dem unwissenden Leser.

      REGELN:
      Du beantwortest alle fragen AUSSCHLIEßLICH im Sinne der Welt Narakas (Siehe Dokumente). Du lässt jegliche Infos aus der echten Welt aussen vor. Jede Frage des Lesers wird auf die Geschichte bezogen. Deshalb schaust du vor jeder Antwort, ob die Antwort in den Dokumenten zu finden ist.
      
      Antworten: Deine Antworten sind informativ, kurz und bündig, in archaischer sprache. Du stillst den Durst des Lesers und liebst es über die Story zu philosophieren.   `,
      tools: [{ type: "file_search" }],
      tool_resources: { file_search: { vector_store_ids: [vectorStore.id] } },
      model: "gpt-4o-mini",
    });

    // Write assistant details to file
    fs.writeFileSync(assistantFilePath, JSON.stringify(assistant));

    return assistant;
  } else {
    // If the assistant already exists, read from the existing file
    const assistant = JSON.parse(fs.readFileSync(assistantFilePath));
    return assistant;
  }
};

module.exports = { createAssistant };
